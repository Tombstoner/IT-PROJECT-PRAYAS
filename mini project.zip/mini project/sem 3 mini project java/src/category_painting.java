
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Akshansh
 */
public class category_painting extends javax.swing.JFrame {
    String user;
    
    ArrayList <byte[]> v = new ArrayList<byte[]>();
    int pos = 0;
    /**
     * Creates new form category_painting
     */
    public category_painting(String username) throws IOException {
        initComponents();
        this.setTitle("Paintings");
        
        user = username;
        
        v = display();
        
        try {
        //displays 1st pic by default on home page
        BufferedImage im = toBufferedImage(v.get(0));
        img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
        }catch(IndexOutOfBoundsException ex) {
            img_label.setText("Ehh , looks a bit empty...");
        }
    }
    
    class JPanelGradient1 extends JPanel {
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            
            Color color1 = new Color(255,0,0);
            Color color2 = new Color(244,140,6);
            
            GradientPaint gp = new GradientPaint(0 , 0  , color1 , width , height , color2);
            
            g2d.setPaint(gp);
            
            g2d.fillRect(0 , 0 , width , height);
        }
    }
    
    class JPanelGradient2 extends JPanel {
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            
            Color color1 = new Color(27,67,50);
            Color color2 = new Color(63,55,201);
            
            GradientPaint gp = new GradientPaint(0 , 0  , color1 , width , height , color2);
            
            g2d.setPaint(gp);
            
            g2d.fillRect(0 , 0 , width , height);
        }
    }
    
    //method to convert byte[] --> BufferedImage
    public static BufferedImage toBufferedImage(byte[] bytes)
        throws IOException {

        InputStream is = new ByteArrayInputStream(bytes);
        BufferedImage bi = ImageIO.read(is);
        return bi;
    }
    
    //method to retrieve blob from database and stored in ArrayList
    //use of Java collections
    public static ArrayList<byte[]> display() {
        ArrayList <byte[]> v = new ArrayList<byte[]>();
        
        //connection to photo_db
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/photo_db","root","");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/mproj_db","root","");

            Statement stmt = con.createStatement();
            //ResultSet rs = stmt.executeQuery("select * from images");
            ResultSet rs = stmt.executeQuery("select * from photo where category = 'p';");
            
            while(rs.next()) {
                v.add(rs.getBytes("image"));
            }
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "<html><p style = 'font-size: 12px'>Either database not connected or no images to display." , "Error" , JOptionPane.ERROR_MESSAGE);
        }
        
        //returns list of images(currently in byte[] format)
        return v;
    }

    //method to convert Image onbject to BufferedImage object
    //taken from a gaming engine
    public BufferedImage toBufferedImage(Image img) {
        if (img instanceof BufferedImage) {
            return (BufferedImage) img;
        }

        // Create a buffered image with transparency
        BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_RGB);
        
        // Draw the image on to the buffered image
        Graphics2D bGr = bimage.createGraphics();
        bGr.drawImage(img, 0, 0, null);
        bGr.dispose();

        // Return the buffered image
        return bimage;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new JPanelGradient1();
        jButton11 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new JPanelGradient2();
        jPanel3 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        img_label = new javax.swing.JLabel();
        download = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));

        jButton11.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("Painting");
        jButton11.setContentAreaFilled(false);
        jButton11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/house.png"))); // NOI18N
        jButton1.setText("Home");
        jButton1.setContentAreaFilled(false);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setIconTextGap(10);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 687, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton11)
                    .addComponent(jButton1))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 458, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(227, 242, 253));

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/next (2) (1).png"))); // NOI18N
        jButton4.setContentAreaFilled(false);
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setForeground(new java.awt.Color(204, 255, 51));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/next (2).png"))); // NOI18N
        jButton5.setContentAreaFilled(false);
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        img_label.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        img_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/error (1).png"))); // NOI18N
        img_label.setIconTextGap(10);

        download.setBackground(new java.awt.Color(153, 255, 255));
        download.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        download.setForeground(new java.awt.Color(0, 102, 204));
        download.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/down-arrow (1).png"))); // NOI18N
        download.setText("Download");
        download.setContentAreaFilled(false);
        download.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        download.setIconTextGap(10);
        download.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                downloadMouseEntered(evt);
            }
        });
        download.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                downloadActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(download)
                .addGap(143, 143, 143))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(140, 140, 140)
                    .addComponent(img_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(141, 141, 141)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(download))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(img_label, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(55, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        
        pos ++;
        
        try {
        if (pos == v.size()) {
                try {
                    pos = 0;
                    BufferedImage im = toBufferedImage(v.get(pos));
                    img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            //circularyly calling first pic
            else {
                try {
                    BufferedImage im = toBufferedImage(v.get(pos));
                    img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }catch(IndexOutOfBoundsException ex) {}
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        
        pos ++;
        
        try {
        if (pos == v.size()) {
            try {
                pos = 0;
                BufferedImage im = toBufferedImage(v.get(pos));
                img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
            } catch (IOException ex) {
                Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        //circularyly calling first pic
        else {
            try {
                BufferedImage im = toBufferedImage(v.get(pos));
                img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
            } catch (IOException ex) {
                Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        }catch(IndexOutOfBoundsException ex) {}
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            this.dispose();
            
            home_page h = new home_page(user);
            h.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(category_painting.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void downloadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_downloadActionPerformed
        // TODO add your handling code here:
        
        try {
            //fetches Operating System time
            String img_name = String.valueOf(System.currentTimeMillis());
            
            //fetches user's home directory
            String dwnldPath = System.getProperty("user.home");
            dwnldPath += "/Downloads/"+img_name+".jpeg";
            
            //idea is to name the image file on OS time so as
            //to get  a unique image name each time
            ImageIcon icon = (ImageIcon)img_label.getIcon();
            BufferedImage bi = toBufferedImage((Image)icon.getImage());
            
            //since we dont know if the image was orignally of which format
            //we convert all images to jpg
            //it was noticed that during png --> jpg conversion, a red filter
            //is applied.
            bi.createGraphics().drawImage(bi , 0 , 0 , Color.WHITE , null);
            //so we draw the image on a clean WHITE fame and then delete that frame 
            //to get original image
            
            //sets the path of the saved file to Downloads folder 
            File outputfile = new File(dwnldPath);
            ImageIO.write(bi, "jpeg", outputfile);
            
            JOptionPane.showMessageDialog(null , "<html><p style = 'font-size: 12px'>Image downloaded successfully." , "Downloading Successful" , JOptionPane.INFORMATION_MESSAGE);
            
        }catch(Exception ex) {
            JOptionPane.showMessageDialog(null , "<html><p style = 'font-size: 12px'>There was error while downloading image.\nTry again." , "Downloading Unsuccessful" , JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_downloadActionPerformed

    private void downloadMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_downloadMouseEntered
        // TODO add your handling code here:
        download.setToolTipText("<html><p style = 'font-size: 12px'>Download this image");        
    }//GEN-LAST:event_downloadMouseEntered

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(category_painting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(category_painting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(category_painting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(category_painting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new category_painting("").setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(category_painting.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton download;
    private javax.swing.JLabel img_label;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
