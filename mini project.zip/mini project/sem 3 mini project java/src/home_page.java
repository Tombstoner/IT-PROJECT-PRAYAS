
import java.awt.Color;
import java.awt.Desktop;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.*;
import java.awt.Image;
import java.awt.List;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Akshansh
 */
public class home_page extends javax.swing.JFrame {
    String user;
    int nothing_sus = 0;
    
    ArrayList <byte[]> v = new ArrayList<byte[]>();
    int pos = 0;
    
    /**
     * Creates new form Img_Viewer
     */
    public home_page(String username) throws IOException {
        initComponents();
        this.setTitle("Xmage Gallery");
        v = display();
        
        try {
        //displays 1st pic by default on home page
        BufferedImage im = toBufferedImage(v.get(0));
        img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
        }catch(IndexOutOfBoundsException ex) {
            img_label.setText("Ehh , looks a bit empty...");
        }
        
        user = username;
        logout.setText("Welcome , " + user);
    }
    
    class JPanelGradient1 extends JPanel {
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            
            Color color1 = new Color(36,0,70);
            Color color2 = new Color(17,138,178);
            
            GradientPaint gp = new GradientPaint(0 , 0  , color1 , width , height , color2);
            
            g2d.setPaint(gp);
            
            g2d.fillRect(0 , 0 , width , height);
        }
    }
    
    class JPanelGradient2 extends JPanel {
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            
            Color color1 = new Color(250,210,225);
            Color color2 = new Color(190,225,230);
            
            GradientPaint gp = new GradientPaint(0 , 0  , color1 , width , height , color2);
            
            g2d.setPaint(gp);
            
            g2d.fillRect(0 , 0 , width , height);
        }
    }
    
    class JPanelGradient3 extends JPanel {
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            
            Color color1 = new Color(0,100,0);
            Color color2 = new Color(56,176,0);
            
            GradientPaint gp = new GradientPaint(0 , 0  , color1 , width , height , color2);
            
            g2d.setPaint(gp);
            
            g2d.fillRect(0 , 0 , width , height);
        }
    }
    
    //method to convert byte[] --> BufferedImage
    public static BufferedImage toBufferedImage(byte[] bytes)
        throws IOException {

        InputStream is = new ByteArrayInputStream(bytes);
        BufferedImage bi = ImageIO.read(is);
        return bi;
    }
    
    //method to retrieve blob from database and stored in ArrayList
    //use of Java collections
    public static ArrayList<byte[]> display() {
        ArrayList <byte[]> v = new ArrayList<byte[]>();
        
        //connection to photo_db
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/photo_db","root","");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/mproj_db","root","");

            Statement stmt = con.createStatement();
            //ResultSet rs = stmt.executeQuery("select * from images");
            ResultSet rs = stmt.executeQuery("select * from photo;");
            
            while(rs.next()) {
                v.add(rs.getBytes("image"));
            }
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "<html><p style = 'font-size: 12px;'>Dtabase empty or improper connection." , "Error" , JOptionPane.ERROR_MESSAGE);
        }
        
        //returns list of images(currently in byte[] format)
        return v;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new JPanelGradient2();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel2 = new JPanelGradient1();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel5 = new JPanelGradient3();
        jLabel5 = new javax.swing.JLabel();
        fb = new javax.swing.JButton();
        gmail = new javax.swing.JButton();
        whatsapp = new javax.swing.JButton();
        linkedin = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        next_img = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        prev_img = new javax.swing.JButton();
        img_label = new javax.swing.JLabel();
        last_img = new javax.swing.JButton();
        first_img = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(199, 249, 204));

        jPanel4.setBackground(new java.awt.Color(200, 0, 0));

        jLabel8.setFont(new java.awt.Font("Gelio Fasolada", 3, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 204, 0));
        jLabel8.setText("A");

        jLabel9.setFont(new java.awt.Font("Gelio Fasolada", 3, 40)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 204, 0));
        jLabel9.setText("PICTURE");

        jLabel10.setFont(new java.awt.Font("Gelio Fasolada", 3, 48)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 204, 0));
        jLabel10.setText("WORTH A");

        jLabel11.setFont(new java.awt.Font("Gelio Fasolada", 3, 52)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 204, 0));
        jLabel11.setText("thousand");

        jLabel12.setFont(new java.awt.Font("Gelio Fasolada", 3, 56)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 204, 0));
        jLabel12.setText("WORDS...");

        jLabel13.setFont(new java.awt.Font("Gelio Fasolada", 3, 44)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 204, 0));
        jLabel13.setText("IS");

        jLabel14.setFont(new java.awt.Font("Gelio Fasolada", 3, 100)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 204, 0));
        jLabel14.setText("\"");

        jLabel15.setFont(new java.awt.Font("Gelio Fasolada", 3, 100)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 204, 0));
        jLabel15.setText("\"");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 12, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jLabel8)))
                .addGap(36, 36, 36)
                .addComponent(jLabel9)
                .addGap(46, 46, 46)
                .addComponent(jLabel13)
                .addGap(56, 56, 56)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66)
                .addComponent(jLabel11)
                .addGap(30, 30, 30)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel14))
                .addContainerGap(110, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(0, 21, 79));

        jLabel1.setBackground(new java.awt.Color(197, 203, 227));
        jLabel1.setFont(new java.awt.Font("Gelio Fasolada", 3, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(244, 175, 27));
        jLabel1.setText("Xmage");

        jLabel3.setFont(new java.awt.Font("Gelio Fasolada", 3, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(244, 175, 27));
        jLabel3.setText("Gallery");

        jButton1.setFont(new java.awt.Font("Tw Cen MT", 1, 28)); // NOI18N
        jButton1.setForeground(new java.awt.Color(250, 243, 221));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/cloud-computing (1).png"))); // NOI18N
        jButton1.setContentAreaFilled(false);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setIconTextGap(10);
        jButton1.setLabel("Uploads");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton1MouseEntered(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        logout.setFont(new java.awt.Font("Tw Cen MT", 1, 28)); // NOI18N
        logout.setForeground(new java.awt.Color(250, 243, 221));
        logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/user (1).png"))); // NOI18N
        logout.setContentAreaFilled(false);
        logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logout.setIconTextGap(10);
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                logoutMouseEntered(evt);
            }
        });
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logout)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel2.setBackground(new java.awt.Color(20, 167, 108));
        jLabel2.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 51));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/gallery.png"))); // NOI18N
        jLabel2.setText("Gallery");
        jLabel2.setIconTextGap(10);

        jPanel5.setBackground(new java.awt.Color(215, 153, 34));

        jLabel5.setFont(new java.awt.Font("Tw Cen MT", 1, 28)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(239, 226, 186));
        jLabel5.setText("Contact Information : ");

        fb.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/facebook.png"))); // NOI18N
        fb.setContentAreaFilled(false);
        fb.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        fb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                fbMouseEntered(evt);
            }
        });
        fb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fbActionPerformed(evt);
            }
        });

        gmail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/gmail.png"))); // NOI18N
        gmail.setContentAreaFilled(false);
        gmail.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        gmail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                gmailMouseEntered(evt);
            }
        });
        gmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gmailActionPerformed(evt);
            }
        });

        whatsapp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/whatsapp.png"))); // NOI18N
        whatsapp.setContentAreaFilled(false);
        whatsapp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        whatsapp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                whatsappMouseEntered(evt);
            }
        });
        whatsapp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                whatsappActionPerformed(evt);
            }
        });

        linkedin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/linkedin.png"))); // NOI18N
        linkedin.setContentAreaFilled(false);
        linkedin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        linkedin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                linkedinMouseEntered(evt);
            }
        });
        linkedin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                linkedinActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Gelio Fasolada", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(239, 226, 186));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/copyright.png"))); // NOI18N
        jLabel6.setText("Group 4");
        jLabel6.setIconTextGap(10);
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(1033, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(fb, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(gmail, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(whatsapp, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(linkedin, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addGap(25, 25, 25))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(gmail)
                    .addComponent(fb)
                    .addComponent(whatsapp)
                    .addComponent(linkedin)))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel6))
        );

        next_img.setBackground(new java.awt.Color(255, 255, 255));
        next_img.setForeground(new java.awt.Color(204, 255, 51));
        next_img.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/next (2).png"))); // NOI18N
        next_img.setContentAreaFilled(false);
        next_img.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        next_img.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                next_imgMouseEntered(evt);
            }
        });
        next_img.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                next_imgActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 21, 79));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        jLabel7.setText("Categories :");
        jLabel7.setIconTextGap(10);

        jButton11.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        jButton11.setForeground(new java.awt.Color(51, 0, 102));
        jButton11.setText("Painting");
        jButton11.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 0, 8, 5, new java.awt.Color(255, 117, 143)));
        jButton11.setContentAreaFilled(false);
        jButton11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        jButton12.setForeground(new java.awt.Color(51, 0, 102));
        jButton12.setText("Photography");
        jButton12.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 0, 8, 5, new java.awt.Color(255, 117, 143)));
        jButton12.setContentAreaFilled(false);
        jButton12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        jButton13.setForeground(new java.awt.Color(51, 0, 102));
        jButton13.setText("Design");
        jButton13.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 0, 8, 5, new java.awt.Color(255, 117, 143)));
        jButton13.setContentAreaFilled(false);
        jButton13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        jButton14.setForeground(new java.awt.Color(51, 0, 102));
        jButton14.setText("Graphic Design");
        jButton14.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 0, 8, 5, new java.awt.Color(255, 117, 143)));
        jButton14.setContentAreaFilled(false);
        jButton14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        jButton15.setForeground(new java.awt.Color(51, 0, 102));
        jButton15.setText("Illustration");
        jButton15.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 0, 8, 5, new java.awt.Color(255, 117, 143)));
        jButton15.setContentAreaFilled(false);
        jButton15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        prev_img.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/next (2) (1).png"))); // NOI18N
        prev_img.setContentAreaFilled(false);
        prev_img.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        prev_img.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                prev_imgMouseEntered(evt);
            }
        });
        prev_img.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prev_imgActionPerformed(evt);
            }
        });

        img_label.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        img_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/error (1).png"))); // NOI18N
        img_label.setIconTextGap(10);

        last_img.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        last_img.setForeground(new java.awt.Color(0, 102, 51));
        last_img.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/image (1).png"))); // NOI18N
        last_img.setText("Last");
        last_img.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 10, new java.awt.Color(255, 102, 0)));
        last_img.setContentAreaFilled(false);
        last_img.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        last_img.setIconTextGap(20);
        last_img.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                last_imgMouseEntered(evt);
            }
        });
        last_img.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                last_imgActionPerformed(evt);
            }
        });

        first_img.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        first_img.setForeground(new java.awt.Color(0, 102, 51));
        first_img.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/picture.png"))); // NOI18N
        first_img.setText("First");
        first_img.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 10, 0, 0, new java.awt.Color(255, 102, 0)));
        first_img.setContentAreaFilled(false);
        first_img.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        first_img.setIconTextGap(20);
        first_img.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                first_imgMouseEntered(evt);
            }
        });
        first_img.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                first_imgActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(108, 108, 108)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(prev_img, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(12, 12, 12)
                                        .addComponent(img_label, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(35, 35, 35)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel7)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(141, 141, 141)
                                                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(76, 76, 76)
                                                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(51, 51, 51)
                                                .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(12, 12, 12)
                                .addComponent(next_img, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel2))
                        .addContainerGap(66, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(first_img, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(last_img, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(105, 105, 105))))
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(prev_img)
                                    .addComponent(img_label, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(61, 61, 61)
                                .addComponent(next_img)))
                        .addGap(7, 7, 7)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(first_img)
                            .addComponent(last_img))
                        .addGap(30, 30, 30)
                        .addComponent(jLabel7)
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void next_imgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_next_imgActionPerformed
        //next button
        
        pos ++;
        
        try {
        if (pos == v.size()) {
            try {
                pos = 0;
                BufferedImage im = toBufferedImage(v.get(pos));
                img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
            } catch (IOException ex) {
                Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        //circularyly calling first pic
        else {
            try {
                BufferedImage im = toBufferedImage(v.get(pos));
                img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
            } catch (IOException ex) {
                Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        }catch(IndexOutOfBoundsException ex) {}
    }//GEN-LAST:event_next_imgActionPerformed

    private void prev_imgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prev_imgActionPerformed
        // TODO add your handling code here:
        //previous button
        
        pos --;
        
        try {
            if (pos < 0) {
                try {
                    pos = v.size() - 1;
                    BufferedImage im = toBufferedImage(v.get(pos));
                    img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            //circularly calling last pic 
            else {
                try {
                    BufferedImage im = toBufferedImage(v.get(pos));
                    img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }catch(IndexOutOfBoundsException ex) {}
    }//GEN-LAST:event_prev_imgActionPerformed

    private void gmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gmailActionPerformed
        //mails to 'akshansh2002@gmail.com'
        
        try {
            Desktop.getDesktop().mail(new URI("mailto:akshansh2002@gmail.com"));
        } catch (URISyntaxException | IOException e) {
            JOptionPane.showMessageDialog(null, "<html><p style = 'font-size: 12px;'>The given link is not woeking or expired.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_gmailActionPerformed

    private void linkedinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_linkedinActionPerformed
        // TODO add your handling code here:
        //button connects to linked in page
        
        try {
            Desktop.getDesktop().browse(new URI("https://www.linkedin.com/in/akshansh-sharma/"));
        } catch (IOException | URISyntaxException e) {
            JOptionPane.showMessageDialog(null, "<html><p style = 'font-size: 12px;'>The given link is not woeking or expired.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_linkedinActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        try {
            this.dispose();
            
            category_painting paint = new category_painting(user);
            paint.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            this.dispose();
            
            user_page u = new user_page(user);
            u.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        try {
            this.dispose();
            
            category_photo photo = new category_photo(user);
            photo.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        try {
            this.dispose();
            
            category_design design = new category_design(user);
            design.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        try {
            this.dispose();
            
            category_graphics_design gdesign = new category_graphics_design(user);
            gdesign.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        try {
            this.dispose();
            
            category_illustration ill = new category_illustration(user);
            ill.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton15ActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        JOptionPane.showMessageDialog(null, "<html><p style = 'font-size: 12px;'>You have successfully logged out.", "Successful log out", JOptionPane.PLAIN_MESSAGE);
        this.dispose();

        login l = new login();
        l.setVisible(true);
    }//GEN-LAST:event_logoutActionPerformed

    private void fbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fbActionPerformed
        // TODO add your handling code here:
        //button connects to facebook page
        
        try {
            Desktop.getDesktop().browse(new URI("https://www.facebook.com/ash.sharma.5621149"));
        } catch (URISyntaxException | IOException e) {
            JOptionPane.showMessageDialog(null, "<html><p style = 'font-size: 12px;'>The given link is not woeking or expired.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_fbActionPerformed

    private void whatsappActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_whatsappActionPerformed
        // TODO add your handling code here:
        //button connects to Akshansh's whatsapp
        
        try {
            Desktop.getDesktop().browse(new URI("https://wa.me/919307984045"));
        } catch (URISyntaxException | IOException e) {
            JOptionPane.showMessageDialog(null, "<html><p style = 'font-size: 12px;'>The given link is not woeking or expired.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_whatsappActionPerformed

    private void first_imgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_first_imgActionPerformed
        // TODO add your handling code here:
        //first image display
        pos = 0;
        
        try {
            try {
                    BufferedImage im = toBufferedImage(v.get(pos));
                    img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
        }catch(IndexOutOfBoundsException ex) {}
    }//GEN-LAST:event_first_imgActionPerformed

    private void last_imgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_last_imgActionPerformed
        // TODO add your handling code here:
        //last image display
        try {
            pos = v.size() - 1;

            try {
                    BufferedImage im = toBufferedImage(v.get(pos));
                    img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
        }catch(IndexOutOfBoundsException ex) {}
    }//GEN-LAST:event_last_imgActionPerformed

    private void logoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseEntered
        // TODO add your handling code here:
        logout.setToolTipText("<html><p style = 'font-size: 12px;'>Log out");
    }//GEN-LAST:event_logoutMouseEntered

    private void prev_imgMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_prev_imgMouseEntered
        // TODO add your handling code here:
        prev_img.setToolTipText("<html><p style = 'font-size: 12px;'>Previous image");
    }//GEN-LAST:event_prev_imgMouseEntered

    private void next_imgMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_next_imgMouseEntered
        // TODO add your handling code here:
        
        next_img.setToolTipText("<html><p style = 'font-size: 12px;'>Next image");
    }//GEN-LAST:event_next_imgMouseEntered

    private void first_imgMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_first_imgMouseEntered
        // TODO add your handling code here:
        first_img.setToolTipText("<html><p style = 'font-size: 12px;'>Go to first image");
    }//GEN-LAST:event_first_imgMouseEntered

    private void last_imgMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_last_imgMouseEntered
        // TODO add your handling code here:
        last_img.setToolTipText("<html><p style = 'font-size: 12px;'>Go to last image");
    }//GEN-LAST:event_last_imgMouseEntered

    private void fbMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fbMouseEntered
        // TODO add your handling code here:
        fb.setToolTipText("<html><p style = 'font-size: 12px;'>Connnect via Facebook");
    }//GEN-LAST:event_fbMouseEntered

    private void gmailMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gmailMouseEntered
        // TODO add your handling code here:
        gmail.setToolTipText("<html><p style = 'font-size: 12px;'>Email us");
    }//GEN-LAST:event_gmailMouseEntered

    private void whatsappMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_whatsappMouseEntered
        // TODO add your handling code here:
        whatsapp.setToolTipText("<html><p style = 'font-size: 12px;'>Connnect via Whatsapp");
    }//GEN-LAST:event_whatsappMouseEntered

    private void linkedinMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_linkedinMouseEntered
        // TODO add your handling code here:
        linkedin.setToolTipText("<html><p style = 'font-size: 12px;'>Connnect via linkedIn");
    }//GEN-LAST:event_linkedinMouseEntered

    private void jButton1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseEntered
        // TODO add your handling code here:
        jButton1.setToolTipText("<html><p style = 'font-size: 12px;'>Go to Uploads page");
    }//GEN-LAST:event_jButton1MouseEntered

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        // TODO add your handling code here:
        nothing_sus ++;
        if (nothing_sus == 5)
            JOptionPane.showMessageDialog(null , "<html><p style = 'font-size: 12px;'>11 clicks to go :)" , "Stop" , JOptionPane.ERROR_MESSAGE);
        else if (nothing_sus == 10)
            JOptionPane.showMessageDialog(null , "<html><p style = 'font-size: 12px;'>6 clicks to go :)" , "Stop" , JOptionPane.ERROR_MESSAGE);
        else if (nothing_sus == 16)
            JOptionPane.showMessageDialog(null , "<html><p style = 'font-size: 12px;'>This project was implemented in <strong>Semester 3</strong> by "
                    + "<strong>Group 4</strong>(copyright).<br><br>This group consisted of students of <strong>St. Francis Institute of Technology</strong><br>1. <em>Akshansh Sharma</em>(<strong>leader</strong>)<br>"
                    + "2. <em>Kunal Shekte</em><br>3. <em>Anuja Shirode<br>4. <em>Adnan Sheikh</em><br><br><strong>Topic</strong> : <em>Image Search Engine using Java and Database</em>" , "About us" , JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jLabel6MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(home_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(home_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(home_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(home_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new home_page("").setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton fb;
    private javax.swing.JButton first_img;
    private javax.swing.JButton gmail;
    private javax.swing.JLabel img_label;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JButton last_img;
    private javax.swing.JButton linkedin;
    private javax.swing.JButton logout;
    private javax.swing.JButton next_img;
    private javax.swing.JButton prev_img;
    private javax.swing.JButton whatsapp;
    // End of variables declaration//GEN-END:variables
}
