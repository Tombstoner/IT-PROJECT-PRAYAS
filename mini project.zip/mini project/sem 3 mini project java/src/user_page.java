
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Akshansh
 */
public class user_page extends javax.swing.JFrame {
    String formatRemember;
    
    String user;
    
    ArrayList <byte[]> v = new ArrayList<byte[]>();
    int pos = 0;
    
    FileInputStream input;
    /**
     * Creates new form user_page
     */
    public user_page(String username) throws IOException {
        initComponents();
        this.setTitle("Downloads");
        
        user = username;
        uname.setText("Welcome , " + user);
        
        v = display();

        //displays 1st pic by default on home page
        
        try {
            BufferedImage im = toBufferedImage(v.get(0));
            img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
        }catch(IndexOutOfBoundsException ex) {
            img_label.setText("Nothing to display here.   Start uploading.");
        }
        
    }
    
    class JPanelGradient1 extends JPanel {
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            
            Color color1 = new Color(36,0,70);
            Color color2 = new Color(17,138,178);
            
            GradientPaint gp = new GradientPaint(0 , 0  , color1 , width , height , color2);
            
            g2d.setPaint(gp);
            
            g2d.fillRect(0 , 0 , width , height);
        }
    }
    
    class JPanelGradient2 extends JPanel {
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            
            Color color1 = new Color(87,204,153);
            Color color2 = new Color(199,249,204);
            
            GradientPaint gp = new GradientPaint(0 , 0  , color1 , width , height , color2);
            
            g2d.setPaint(gp);
            
            g2d.fillRect(0 , 0 , width , height);
        }
    }
    
    class JPanelGradient3 extends JPanel {
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            
            Color color1 = new Color(36,0,70);
            Color color2 = new Color(242,0,137);
            
            GradientPaint gp = new GradientPaint(0 , 0  , color1 , width , height , color2);
            
            g2d.setPaint(gp);
            
            g2d.fillRect(0 , 0 , width , height);
        }
    }
    
    public boolean formatChecker(File file) {
         String filename = file.getName();
         int dotIndex = filename.lastIndexOf('.');
         
         String format = filename.substring(dotIndex + 1);
         
         if (format.equalsIgnoreCase("jpg") || format.equalsIgnoreCase("jpeg") || format.equalsIgnoreCase("png"))
             return true;
         else
             return false;
    }
    
    public String formatRemember(File file) {
        String filename = file.getName();
        int dotIndex = filename.lastIndexOf('.');

        String format = filename.substring(dotIndex + 1);
        
        return format;
    }
    
    //method to convert byte[] --> BufferedImage
    public BufferedImage toBufferedImage(byte[] bytes)
        throws IOException {

        InputStream is = new ByteArrayInputStream(bytes);
        BufferedImage bi = ImageIO.read(is);
        return bi;
    }
    
    //method to retrieve blob from database and stored in ArrayList
    //use of Java collections
    public ArrayList<byte[]> display() {
        ArrayList <byte[]> v = new ArrayList<byte[]>();
        
        //connection to photo_db
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/photo_db","root","");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/mproj_db","root","");

            Statement stmt = con.createStatement();
            //ResultSet rs = stmt.executeQuery("select * from images");
            ResultSet rs = stmt.executeQuery("select * from photo where username = '" + user + "';");
            
            while(rs.next()) {
                v.add(rs.getBytes("image"));
            }
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "<html><p style = 'font-size: 12px'>Either database not connected or no images to display." , "Error" , JOptionPane.ERROR_MESSAGE);
        }
        
        //returns list of images(currently in byte[] format)
        return v;
    }

    public String catList(String word) {
        if (word.contains("Painting"))
            return "p";
        else if (word.contains("Photography"))
            return "ph";
        else if (word.contains("Graphic Design"))
            return "gd";
        else if (word.contains("Design"))
            return "d";
        else if (word.contains("Illustration"))
            return "i";
        else
            return "p";
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new JPanelGradient2();
        jPanel2 = new JPanelGradient1();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        uname = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new JPanelGradient3();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        prev_img = new javax.swing.JButton();
        next_img = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        choose = new javax.swing.JButton();
        address = new javax.swing.JLabel();
        upload = new javax.swing.JButton();
        list = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        img_label = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.LINE_AXIS));

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        jPanel2.setBackground(new java.awt.Color(0, 21, 79));

        jLabel1.setBackground(new java.awt.Color(197, 203, 227));
        jLabel1.setFont(new java.awt.Font("Gelio Fasolada", 3, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(244, 175, 27));
        jLabel1.setText("Xmage");

        jLabel3.setFont(new java.awt.Font("Gelio Fasolada", 3, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(244, 175, 27));
        jLabel3.setText("Gallery");

        uname.setFont(new java.awt.Font("Tw Cen MT", 1, 28)); // NOI18N
        uname.setForeground(new java.awt.Color(250, 243, 221));
        uname.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/user (1).png"))); // NOI18N
        uname.setIconTextGap(10);

        jButton1.setFont(new java.awt.Font("Tw Cen MT", 1, 28)); // NOI18N
        jButton1.setForeground(new java.awt.Color(250, 243, 221));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/house.png"))); // NOI18N
        jButton1.setText("Home");
        jButton1.setContentAreaFilled(false);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setIconTextGap(10);
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton1MouseEntered(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(uname)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jButton1))
                            .addComponent(jLabel1))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                        .addComponent(uname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(51, 0, 102));

        jLabel8.setFont(new java.awt.Font("Gelio Fasolada", 3, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("\" When");

        jLabel9.setFont(new java.awt.Font("Gelio Fasolada", 3, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("I have a");

        jLabel10.setFont(new java.awt.Font("Gelio Fasolada", 3, 36)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("in my hand");

        jLabel11.setFont(new java.awt.Font("Gelio Fasolada", 3, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(244, 175, 27));
        jLabel11.setText("camera");

        jLabel12.setFont(new java.awt.Font("Gelio Fasolada", 3, 36)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("I know ");

        jLabel13.setFont(new java.awt.Font("Gelio Fasolada", 3, 50)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(244, 175, 27));
        jLabel13.setText("no fear");

        jLabel14.setFont(new java.awt.Font("Gelio Fasolada", 3, 36)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("\"");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(13, 13, 13)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(12, 12, 12)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(167, 167, 167)
                .addComponent(jLabel8)
                .addGap(15, 15, 15)
                .addComponent(jLabel9)
                .addGap(20, 20, 20)
                .addComponent(jLabel11)
                .addGap(25, 25, 25)
                .addComponent(jLabel10)
                .addGap(30, 30, 30)
                .addComponent(jLabel12)
                .addGap(50, 50, 50)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        prev_img.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/next (2) (1).png"))); // NOI18N
        prev_img.setContentAreaFilled(false);
        prev_img.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        prev_img.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                prev_imgMouseEntered(evt);
            }
        });
        prev_img.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prev_imgActionPerformed(evt);
            }
        });

        next_img.setBackground(new java.awt.Color(255, 255, 255));
        next_img.setForeground(new java.awt.Color(204, 255, 51));
        next_img.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/next (2).png"))); // NOI18N
        next_img.setContentAreaFilled(false);
        next_img.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        next_img.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                next_imgMouseEntered(evt);
            }
        });
        next_img.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                next_imgActionPerformed(evt);
            }
        });

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Recently Uploaded Images : ");

        jLabel5.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 102, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/upload.png"))); // NOI18N
        jLabel5.setText("Uploads");
        jLabel5.setIconTextGap(10);

        jLabel15.setFont(new java.awt.Font("Gelio Fasolada", 1, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(51, 0, 102));
        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/copyright.png"))); // NOI18N
        jLabel15.setText("Group 4");

        jLabel2.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 102, 0));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/photo.png"))); // NOI18N
        jLabel2.setText("Upload Image");
        jLabel2.setIconTextGap(10);

        choose.setBackground(new java.awt.Color(199, 249, 204));
        choose.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        choose.setForeground(new java.awt.Color(51, 0, 102));
        choose.setText("Choose Image");
        choose.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 10, 0, 4, new java.awt.Color(244, 175, 27)));
        choose.setContentAreaFilled(false);
        choose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        choose.setOpaque(true);
        choose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                chooseMouseEntered(evt);
            }
        });
        choose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chooseActionPerformed(evt);
            }
        });

        address.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        address.setForeground(new java.awt.Color(51, 0, 102));
        address.setText("File Path");
        address.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addressMouseEntered(evt);
            }
        });

        upload.setBackground(new java.awt.Color(199, 249, 204));
        upload.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        upload.setForeground(new java.awt.Color(51, 0, 102));
        upload.setText("Upload");
        upload.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 4, 0, 10, new java.awt.Color(244, 175, 27)));
        upload.setContentAreaFilled(false);
        upload.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        upload.setOpaque(true);
        upload.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                uploadMouseEntered(evt);
            }
        });
        upload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadActionPerformed(evt);
            }
        });

        list.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        list.setForeground(new java.awt.Color(51, 0, 102));
        list.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Painting (*.jpeg)", "Photography (*.jpg , *.jpeg)", "Design (any image format)", "Graphic Design (any image format)", "Illustration (*.png)" }));
        list.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        list.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 0, 102));
        jLabel6.setText("Select Category :");

        img_label.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        img_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/error (1).png"))); // NOI18N
        img_label.setIconTextGap(10);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(prev_img, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addContainerGap(487, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(img_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(next_img, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(70, 70, 70))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(59, 59, 59)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(choose, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(48, 48, 48)
                                        .addComponent(address, javax.swing.GroupLayout.PREFERRED_SIZE, 471, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(list, javax.swing.GroupLayout.PREFERRED_SIZE, 529, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(upload, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addComponent(jLabel2)))
                        .addGap(0, 45, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel15))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(img_label, javax.swing.GroupLayout.PREFERRED_SIZE, 421, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prev_img)
                            .addComponent(next_img))
                        .addGap(23, 23, 23)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(upload, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                            .addComponent(choose, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                            .addComponent(address, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(list, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(32, 32, 32)
                        .addComponent(jLabel15))))
        );

        getContentPane().add(jPanel1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void prev_imgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prev_imgActionPerformed
        // TODO add your handling code here:
        
        pos --;
        
        try {
            if (pos < 0) {
                try {
                    pos = v.size() - 1;
                    BufferedImage im = toBufferedImage(v.get(pos));
                    img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            //circularly calling last pic 
            else {
                try {
                    BufferedImage im = toBufferedImage(v.get(pos));
                    img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }catch(IndexOutOfBoundsException ex) {}
    }//GEN-LAST:event_prev_imgActionPerformed

    private void next_imgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_next_imgActionPerformed
        // TODO add your handling code here:
        
        pos ++;
        
        try {
        if (pos == v.size()) {
                try {
                    pos = 0;
                    BufferedImage im = toBufferedImage(v.get(pos));
                    img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            //circularyly calling first pic
            else {
                try {
                    BufferedImage im = toBufferedImage(v.get(pos));
                    img_label.setIcon(new ImageIcon(new ImageIcon(im).getImage().getScaledInstance(img_label.getWidth() , img_label.getHeight() , Image.SCALE_SMOOTH)));
                } catch (IOException ex) {
                    Logger.getLogger(home_page.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }catch(IndexOutOfBoundsException ex) {}
    }//GEN-LAST:event_next_imgActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            this.dispose();
            
            home_page h = new home_page(user);
            h.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(user_page.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed
    
    private void chooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chooseActionPerformed
        // TODO add your handling code here:
        //image chooser
       
        try {
            JFileChooser chooser = new JFileChooser();
            chooser.setCurrentDirectory(new File("user.dir"));

            FileNameExtensionFilter filter = new FileNameExtensionFilter("All Images", "png", "jpeg", "jpg");
            chooser.addChoosableFileFilter(filter);

            int selected = chooser.showOpenDialog(null);

            if (selected == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                
                formatRemember = formatRemember(file);
                
                if (formatChecker(file) == false)
                        JOptionPane.showMessageDialog(null , "File selected is not an image." , "Error" , JOptionPane.ERROR_MESSAGE);
                else {
                    String filename = file.getAbsolutePath();
                    address.setText(filename);

                    //String filepath = "<html><p style = 'font-size: 15px'>" + filename;
                    //JOptionPane.showMessageDialog(null, filepath , "File address" , JOptionPane.INFORMATION_MESSAGE);
                    ImageIcon imIco = new ImageIcon(filename);
                    //JOptionPane.showMessageDialog(null,  , "Image" , JOptionPane.INFORMATION_MESSAGE);
                    int conf = JOptionPane.showConfirmDialog(null , "" , "Confirm Image ?" , JOptionPane.YES_NO_OPTION , JOptionPane.QUESTION_MESSAGE , imIco);

                    if (conf == JOptionPane.YES_OPTION) {
                        try {
                            File file_ = new File(filename);
                            input = new FileInputStream(file_);

                        } catch (FileNotFoundException ex) {
                            Logger.getLogger(user_page.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    else {
                        address.setText("");
                    }
                }
            }
        }catch(Exception ex) {
            JOptionPane.showMessageDialog(null , ex);
        }
        
    }//GEN-LAST:event_chooseActionPerformed
    
    private void uploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uploadActionPerformed
        // TODO add your handling code here:
        //Upload to table
        System.out.println(formatRemember);
        try {
            if (list.getSelectedItem().toString().contains("Painting") && !formatRemember.equalsIgnoreCase("jpeg"))
                JOptionPane.showMessageDialog(null , "<html><p style = 'font-size: 12px;'>Please upload image of allowed format only." , "Error" , JOptionPane.ERROR_MESSAGE);

            else if (list.getSelectedItem().toString().contains("Photography") && (!formatRemember.equalsIgnoreCase("jpg") && !formatRemember.equalsIgnoreCase("jpeg")))
                JOptionPane.showMessageDialog(null , "<html><p style = 'font-size: 12px;'>Please upload image of allowed format only." , "Error" , JOptionPane.ERROR_MESSAGE);

            else if (list.getSelectedItem().toString().contains("Illustration") && !formatRemember.equalsIgnoreCase("png"))
                JOptionPane.showMessageDialog(null , "<html><p style = 'font-size: 12px;'>Please upload image of allowed format only." , "Error" , JOptionPane.ERROR_MESSAGE);

            else {
                String sql1 = "insert into photo values (? , ? , ?);";
                try{
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/mproj_db","root","");
                    PreparedStatement pst = con.prepareStatement(sql1);

                    pst.setBlob(1, input);
                    pst.setString(2 , user);

                    String categ = catList(list.getSelectedItem().toString());
                    pst.setString(3 , categ);

                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "<html><p style = 'font-size: 12px'>File uploaded successfully!", "Successful Upload", JOptionPane.PLAIN_MESSAGE);

                    con.close();
                    
                    v = display();
                    img_label.setText("");
                    
                }
                catch(Exception ex){
                    JOptionPane.showMessageDialog(null, "<html><p style = 'font-size: 12px'>Select image first to upload." , "Error" ,  JOptionPane.ERROR_MESSAGE);

                }
            }
        }catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }//GEN-LAST:event_uploadActionPerformed

    private void chooseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chooseMouseEntered
        // TODO add your handling code here:
        choose.setToolTipText("<html><p style = 'font-size: 12px'>Choose image to upload");
    }//GEN-LAST:event_chooseMouseEntered

    private void addressMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addressMouseEntered
        // TODO add your handling code here:
        address.setToolTipText("<html><p style = 'font-size: 12px'>Displays image location");
    }//GEN-LAST:event_addressMouseEntered

    private void uploadMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_uploadMouseEntered
        // TODO add your handling code here:
        upload.setToolTipText("<html><p style = 'font-size: 12px'>Click to upload image");
    }//GEN-LAST:event_uploadMouseEntered

    private void prev_imgMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_prev_imgMouseEntered
        // TODO add your handling code here:
        prev_img.setToolTipText("<html><p style = 'font-size: 12px'>Previous image");
    }//GEN-LAST:event_prev_imgMouseEntered

    private void next_imgMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_next_imgMouseEntered
        // TODO add your handling code here:
        next_img.setToolTipText("<html><p style = 'font-size: 12px'>Next image");
    }//GEN-LAST:event_next_imgMouseEntered

    private void jButton1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseEntered
        // TODO add your handling code here:
        jButton1.setToolTipText("<html><p style = 'font-size: 12px'>Back to Home page");
    }//GEN-LAST:event_jButton1MouseEntered

    private void listActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_listActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(user_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(user_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(user_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(user_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new user_page("").setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(user_page.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel address;
    private javax.swing.JButton choose;
    private javax.swing.JLabel img_label;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JComboBox<String> list;
    private javax.swing.JButton next_img;
    private javax.swing.JButton prev_img;
    private javax.swing.JLabel uname;
    private javax.swing.JButton upload;
    // End of variables declaration//GEN-END:variables
}
